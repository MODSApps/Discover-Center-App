package app.mods.org.mainpage;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //icon
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.actionicon);

        View otterButton = findViewById(R.id.wurt);
        otterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.otters");
                startActivity(launchintent);

            }
        });

        View toflyButton = findViewById(R.id.tofly);
        toflyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.tofly");
                startActivity(launchintent);

            }
        });

        View gameButton = findViewById(R.id.discoverycenter);
        gameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

    }
        });
        View stormButton = findViewById(R.id.stormcenter);
        stormButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
        View gogreenButton = findViewById(R.id.goGreen);
        gogreenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
        View ecoscapesButton = findViewById(R.id.ecoScapessalt);
        ecoscapesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
        View powerButton = findViewById(R.id.powerfulYou);
        powerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
        View preButton = findViewById(R.id.prehistoricFlorida);
        preButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
        View floridaButton = findViewById(R.id.floridaWaterstory);
        floridaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
        View mineralButton = findViewById(R.id.mineralsFossils);
        mineralButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
        View ecoButton = findViewById(R.id.ecoScapes);
        ecoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
        View gizmoButton = findViewById(R.id.gizmo);
        gizmoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent launchintent = getPackageManager().getLaunchIntentForPackage("org.example.discoverycenter");
                startActivity(launchintent);

            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.mappa:
                Intent intent = new Intent();
                intent.setAction("app.mods.org.mainpage");
                sendBroadcast(intent);
                //startActivity(new Intent(this, MapActivity.class));
                //return true;
            // More items go here (if any) ...
        }
        return false;
    }


}


