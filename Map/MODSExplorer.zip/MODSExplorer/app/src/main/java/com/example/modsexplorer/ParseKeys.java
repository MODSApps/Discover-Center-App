package com.example.modsexplorer;

public final class ParseKeys
{
	/**
	 * This is the main identifier that uniquely specifies your application. This is paired with a key to
	 * provide your clients access to your application's data.
	 */
	public static final String APPLICATION_ID = "ZSQLLL6acCgg1u0yT47CGuUbsdWgb6RTIrwe1ezt";
	
	/**
	 * This key should be used in consumer clients.
	 */
	public static final String CLIENT_KEY = "8yL0ldCn0jUVVEUGuo8sN7WomUoBoECwj2ItFMzN";
	
	/**
	 * Class constructor has private access.
	 */
	private ParseKeys() 
	{ 
		
	}
}