package org.example.sudoku;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.MediaController;
import android.widget.VideoView;
import android.util.Log;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer;


public class BenchesPage extends Activity {
   ProgressDialog pDialog;
   VideoView videoview;

   String Movie_url = "http://0.s3.envato.com/h264-video-previews/80fad324-9db4-11e3-bf3d-0050569255a8/490527.mp4";
   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.about);
      Intent i = getIntent();
      //video goes here
      videoview = (VideoView) findViewById(R.id.VideoView);

      //Progressbar
      pDialog = new ProgressDialog(BenchesPage.this);
      //Set progressbar title
      pDialog.setTitle("Reasons Why You Should Get Off The Bench");
      //Set Progressbar message
      pDialog.setMessage("Trying different benches");
      pDialog.setIndeterminate(false);
      pDialog.setCancelable(true);
      // Show progressbar
      pDialog.show();
      try {
         //Start the MediaController
         MediaController mediacontroller = new MediaController(BenchesPage.this);
         mediacontroller.setAnchorView(videoview);
         //vv.setVideoPath("www.youtube.com/watch?v=Qcly9NiNbmo");
         Uri video = Uri.parse(Movie_url);
         videoview.setMediaController(new MediaController(this));
         videoview.setVideoURI(video);
      } catch (Exception e) {
         Log.e("Error", e.getMessage());
         e.printStackTrace();
      }

      videoview.requestFocus();
      videoview.setOnPreparedListener(new OnPreparedListener() {
         //Close the progress bar and play the video
         public void onPrepared(MediaPlayer mp) {
            pDialog.dismiss();
            videoview.start();
         }
      });
   }

   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
      // Inflate the menu; this adds items to the action bar if it is present.
      getMenuInflater().inflate(R.menu.menu_second_page, menu);
      return true;
   }

   @Override
   public boolean onOptionsItemSelected(MenuItem item) {
      // Handle action bar item clicks here. The action bar will
      // automatically handle clicks on the Home/Up button, so long
      // as you specify a parent activity in AndroidManifest.xml.
      int id = item.getItemId();

      //noinspection SimplifiableIfStatement
      if (id == R.id.action_settings) {
         return true;
      }

      return super.onOptionsItemSelected(item);
   }
}
